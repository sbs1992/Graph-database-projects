import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Label;
import org.neo4j.graphdb.RelationshipType;
import org.neo4j.graphdb.factory.GraphDatabaseFactory;
import org.neo4j.graphdb.factory.GraphDatabaseSettings;
import org.neo4j.unsafe.batchinsert.BatchInserter;
import org.neo4j.unsafe.batchinsert.BatchInserters;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class Assign7updateDB {


/*    public static void createNodes(String label,String[] nd){

        System.out.println(bi+"");
        for(String s:nd){

            String[] sp=s.split(" ");
            String lb=sp[0]+label;
            bi.createNode(Integer.parseInt(lb),new HashMap<>(), Label.label(sp[1]));




        }



    }

    public static void createRelationships(String label,String[]nd){

        for(String s:nd){

            String[] sp=s.split(" ");
            String n1=sp[0]+label;
            String n2=sp[1]+label;
            bi.createRelationship(Integer.parseInt(n1),Integer.parseInt(n2), RelationshipType.withName("link"),new HashMap<>());


        }


    }*/


    public static void main(String args[]) throws Exception{


        File fold=new File("G:\\sem3\\graph _db\\protiensDB\\Proteins\\Proteins\\target");
        File[] allfiles=fold.listFiles();
        BatchInserter bi=null;
        try {

            // GraphDatabaseService db = new GraphDatabaseFactory() .newEmbeddedDatabaseBuilder(new File("ProtiensNeo")) .setConfig(GraphDatabaseSettings.pagecache_memory, "512M" ) .setConfig(GraphDatabaseSettings.string_block_size, "60" ) .setConfig(GraphDatabaseSettings.array_block_size, "300" ) .newGraphDatabase();
            bi = BatchInserters.inserter(new File("ProtiensGQL"));
            String lab="";
            int cntr=40000;
            int index=1;
            for (int i = 0; i < allfiles.length; i++) {

                System.out.println(allfiles[i].getName().substring(0,allfiles[i].getName().length()-4));
                // getting profiles...




                HashMap<Integer,String> profiles=new HashMap<>();
                HashMap<Integer,String> labelmatch=new HashMap<>();
                BufferedReader br1=new BufferedReader(new FileReader(allfiles[i]));

                String line="";
                int count=0;
                int nr=0;


                //lab="89"+cntr;
                while((line=br1.readLine())!=null){

                    count=Integer.parseInt(line);

                    String[] nodes=new String[count];
                    int ind=0;

                    while(ind<count){

                        nodes[ind]=br1.readLine();
                        ind++;

                    }



                    if(nr==0){
                        //store nodes labels...
                        for(String s:nodes){

                            String[] sp=s.trim().split(" +");
                            //String lb=sp[0]+lab;
                            int lb=Integer.parseInt(sp[0]);
                            //bi.createNode(Integer.parseInt(lb),new HashMap<>(), Label.label(sp[1]));

                           labelmatch.put(lb,sp[1]);



                        }


                    }
                    else{
                        //create relationships...
                        ArrayList<String> pval=new ArrayList<>();
                        int nlab=-1;
                        for(String s:nodes){

                            String[] sp=s.split(" ");
                            //String n1=sp[0]+lab;
                            //String n2=sp[1]+lab;
                            int n1=Integer.parseInt(sp[0]);
                            nlab=n1;
                            int n2=Integer.parseInt(sp[1]);

                            if(!profiles.containsKey(n1)){

                                pval.add(labelmatch.get(n1));
                                pval.add(labelmatch.get(n2));
                                profiles.put(n1,"");
                            }
                            else{
                                pval.add(labelmatch.get(n2));


                            }

                            //bi.createRelationship(Integer.parseInt(n1),Integer.parseInt(n2), RelationshipType.withName("link"),new HashMap<>());



                        }

                        Collections.sort(pval);

                        String finlab="";
                        for(String sl:pval){

                            finlab+=sl;

                        }

                        profiles.put(nlab,finlab);






                    }
                    nr++;
                }



















                //main insertion....

                BufferedReader br=new BufferedReader(new FileReader(allfiles[i]));

                line="";
                count=0;
                nr=0;


                //lab="89"+cntr;
                while((line=br.readLine())!=null){

                    count=Integer.parseInt(line);

                    String[] nodes=new String[count];
                    int ind=0;

                    while(ind<count){

                        nodes[ind]=br.readLine();
                        ind++;

                    }



                    if(nr==0){
                        //create nodes...
                        for(String s:nodes){

                            String[] sp=s.trim().split(" +");
                            //String lb=sp[0]+lab;
                            int lb=Integer.parseInt(sp[0])+cntr;
                            //bi.createNode(Integer.parseInt(lb),new HashMap<>(), Label.label(sp[1]));

                            Map<String,Object> hmap=new HashMap<>();
                            hmap.put("id",lb);
                            hmap.put("name",sp[1]);
                            //System.out.println("id: "+(lb-cntr)+"  profile: "+profiles.get(lb-cntr));
                            hmap.put("profile",profiles.get(lb-cntr));
                            bi.createNode(lb,hmap, Label.label(sp[1]+"_"+allfiles[i].getName().substring(0,allfiles[i].getName().length()-4)));




                        }


                    }
                    else{
                        //create relationships...
                        for(String s:nodes){

                            String[] sp=s.split(" ");
                            //String n1=sp[0]+lab;
                            //String n2=sp[1]+lab;
                            int n1=Integer.parseInt(sp[0])+cntr;
                            int n2=Integer.parseInt(sp[1])+cntr;
                            //bi.createRelationship(Integer.parseInt(n1),Integer.parseInt(n2), RelationshipType.withName("link"),new HashMap<>());
                            bi.createRelationship(n1,n2, RelationshipType.withName("link"),new HashMap<>());


                        }



                    }
                    nr++;
                }

                cntr=cntr+10000*index;
                System.out.println("file"+index);
                index++;


                //break;

            }
            //System.out.println(allfiles.length);

        }
        catch(Exception e){

            e.printStackTrace();
        }

        finally{

            if(bi!=null)
                bi.shutdown();


        }
    }
}
