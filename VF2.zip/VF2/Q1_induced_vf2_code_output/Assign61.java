import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Result;
import org.neo4j.graphdb.factory.GraphDatabaseFactory;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.*;

public class Assign61 {


    static Result res=null;
    static GraphDatabaseFactory dbFactory = new GraphDatabaseFactory();
    static GraphDatabaseService db=dbFactory.newEmbeddedDatabase(new File("ProtiensNeoNewID"));;
    static int subloopbreak=0;

    public static HashMap<String,String> hglob=new HashMap<>();

    public static HashMap<Integer, ArrayList<String>> h8=new HashMap<>();
    public static HashMap<Integer,ArrayList<String>> h8val=new HashMap<>();
    public static HashMap<Integer,Integer> h8cnt=new HashMap<>();

    public static HashMap<Integer,ArrayList<String>> h16=new HashMap<>();
    public static HashMap<Integer,ArrayList<String>> h16val=new HashMap<>();
    public static HashMap<Integer,Integer> h16cnt=new HashMap<>();

    public static HashMap<Integer,ArrayList<String>> h32=new HashMap<>();
    public static HashMap<Integer,ArrayList<String>> h32val=new HashMap<>();
    public static HashMap<Integer,Integer> h32cnt=new HashMap<>();

    public static HashMap<Integer,ArrayList<String>> h64=new HashMap<>();
    public static HashMap<Integer,ArrayList<String>> h64val=new HashMap<>();
    public static HashMap<Integer,Integer> h64cnt=new HashMap<>();

    public static HashMap<Integer,ArrayList<String>> h128=new HashMap<>();
    public static HashMap<Integer,ArrayList<String>> h128val=new HashMap<>();
    public static HashMap<Integer,Integer> h128cnt=new HashMap<>();

    public static HashMap<Integer,ArrayList<String>> h256=new HashMap<>();
    public static HashMap<Integer,ArrayList<String>> h256val=new HashMap<>();
    public static HashMap<Integer,Integer> h256cnt=new HashMap<>();


    public static HashMap<String,String> QueryU=new HashMap<>();

    public static ArrayList<Integer> path=new ArrayList<>();
    static HashMap<Integer,ArrayList<Integer>> adjacenylist=new HashMap<>();

    static ArrayList<String> subgoutput=new ArrayList<>();
    static int dfsrun=0;

/*    public static void route(HashMap<Integer,ArrayList<Integer>> hadj){




    }
    */

    public static void DFS(int x,HashMap<Integer,ArrayList<Integer>> hadj){
        if(!path.contains(x)) {
            path.add(x);
        }

        for(int y:hadj.get(x)){

            if(path.size()==hadj.size()){

                return;
            }
            else if(path.contains(y)){

                continue;

            }
            else{

                path.add(y);
                DFS(y,hadj);
            }
        }



    }



    public static ArrayList<String> parser(String given,String lab) {
        hglob=new HashMap<>();
        QueryU=new HashMap<>();
        String outqry = "";
        String[] sp = given.split("\\n");
        HashMap<String, ArrayList<String>> hm = new HashMap<>();
        HashMap<String, String> hmm = new HashMap<>();
        ArrayList<ArrayList<String>> arel = new ArrayList<>();

        ArrayList<String> allqueries = new ArrayList<>();

        List<ArrayList<ArrayList<String>>> relations = new ArrayList<ArrayList<ArrayList<String>>>();

        adjacenylist=new HashMap<>();
        ArrayList<Integer> hele=new ArrayList<>();
        int ky=0;


        //System.out.println("in...."+hglob.size());
        for (String s : sp) {

            //System.out.println(s);
            String inner[] = s.trim().split(" +");
            // System.out.println(inner[0]);
            if (inner.length == 1) {
                //System.out.println("inner in: "+inner[0]);
                if (arel.size() > 0) {
                    //System.out.println("relations: "+arel);
                    //System.out.println("bef rel: "+relations);
                    relations.add(arel);
                    //System.out.println("in rel: "+relations);
                    adjacenylist.put(ky,hele);

                    hele=new ArrayList<>();

                    arel=new ArrayList<ArrayList<String>>();;
                }
                continue;
            }


            if (!hmm.containsKey("n" + inner[0])) {

                hglob.put(inner[0], "n" + inner[0] + ".id");
                QueryU.put(inner[0],inner[1] + lab);
                hmm.put("n" + inner[0], inner[1] + lab);
                //System.out.println(hglob.size());
                ArrayList<String> al = new ArrayList<>();
                for (int i = 2; i < inner.length; i++) {

                    al.add(inner[i]);
                }
                // System.out.println(al);
                if (al.size() > 0) {
                    hm.put(inner[0], al);
                }

            } else {

                ArrayList<String> ar = new ArrayList<>();

                ky=Integer.parseInt(inner[0]);
                hele.add(Integer.parseInt(inner[1]));
                for (String sin : inner) {

                    if (sin.trim().length() != 0)
                        ar.add("n" + sin);
                }
                arel.add(ar);


            }


        }

        relations.add(arel);

        adjacenylist.put(ky,hele);

        hele=new ArrayList<>();

        arel=new ArrayList<>();


        //System.out.println("adj list: "+adjacenylist);



        if(dfsrun==0) {
            dfsrun=1;

           /* for (int i : adjacenylist.keySet()) {
                DFS(i, adjacenylist);
                break;
            }
*/
        }
        //System.out.println("relationsmap: "+relations);


        // for(String smap:hmm.keySet()) {
        for(ArrayList<ArrayList<String>> are:relations){

            //System.out.println("are: "+are);
            outqry="";
            outqry += "MATCH ";
            int cntx = 0;
            String printernode = "";

            HashMap<String,Integer> samenode=new HashMap<>();
            for (ArrayList<String> a : are) {


                for (String s1 : a) {

                    if(!samenode.containsKey(s1)){
                        samenode.put(s1,1);
                    }

                    if (cntx == 0) {
                        printernode = s1;
                        cntx = 1;
                    }
                    outqry += "(" + s1 + ":" + hmm.get(s1) + ")--";
                }
                outqry = outqry.substring(0, outqry.length() - 2) + ",\n";

            }


            //}
            outqry = outqry.substring(0, outqry.length() - 2) + "\n" + "WHERE ";

            for (String k : samenode.keySet()) {

                //ArrayList<String> a=hm.get(k);

                int cntry = 0;
                for (String s2 : samenode.keySet()) {

                    if (cntry == 1) {
                        outqry += k + ".id<>" + s2 + ".id AND ";
                    } else if (k.equals(s2)) {
                        cntry = 1;
                    }

                }


            }
            outqry = outqry.substring(0, outqry.length() - 4) + "\n" + "RETURN DISTINCT "+printernode+".id";

            /*for (String k : hmm.keySet()) {

                outqry += k + ".id,";

            }
            outqry = outqry.substring(0, outqry.length() - 1) + "\n";*/

            allqueries.add(outqry);
        }



        return allqueries;
    }



    public static void fillGT(String fn,int oct) throws Exception{

        BufferedReader br=new BufferedReader(new FileReader(fn));
        if(oct==8){
            String line="";
            int hind=0;
            while((line=br.readLine())!=null){
                if(line.trim().length()==0){
                    hind++;
                }
                else{

                    ArrayList<String> fnam=new ArrayList<>();
                    fnam.add(line.trim());
                    fnam.add(br.readLine().trim());
                    h8.put(hind,fnam);
                    h8cnt.put(hind,Integer.parseInt(br.readLine().trim().substring(2)));
                    ArrayList<String> data=new ArrayList<>();
                    int datacnt=0;

                    while(datacnt<h8cnt.get(hind)){

                        data.add(br.readLine().trim());datacnt++;
                    }
                    h8val.put(hind,data);

                }

            }


        }
        else if(oct==16){
            String line="";
            int hind=0;
            while((line=br.readLine())!=null){
                if(line.trim().length()==0){
                    hind++;
                }
                else{

                    ArrayList<String> fnam=new ArrayList<>();
                    fnam.add(line.trim());
                    fnam.add(br.readLine().trim());
                    h16.put(hind,fnam);
                    h16cnt.put(hind,Integer.parseInt(br.readLine().trim().substring(2)));
                    ArrayList<String> data=new ArrayList<>();
                    int datacnt=0;

                    while(datacnt<h16cnt.get(hind)){

                        data.add(br.readLine().trim());datacnt++;
                    }
                    h16val.put(hind,data);

                }

            }


        }
        else if(oct==32){
            String line="";
            int hind=0;
            while((line=br.readLine())!=null){
                if(line.trim().length()==0){
                    hind++;
                }
                else{

                    ArrayList<String> fnam=new ArrayList<>();
                    fnam.add(line.trim());
                    fnam.add(br.readLine().trim());
                    h32.put(hind,fnam);
                    h32cnt.put(hind,Integer.parseInt(br.readLine().trim().substring(2)));
                    ArrayList<String> data=new ArrayList<>();
                    int datacnt=0;

                    while(datacnt<h32cnt.get(hind)){

                        data.add(br.readLine().trim());datacnt++;
                    }
                    h32val.put(hind,data);

                }

            }


        }
        else if(oct==64){
            String line="";
            int hind=0;
            while((line=br.readLine())!=null){
                //System.out.println("line: "+line);
                if(line.trim().length()==0){
                    hind++;
                }
                else{

                    ArrayList<String> fnam=new ArrayList<>();
                    fnam.add(line.trim());
                    fnam.add(br.readLine().trim());
                    h64.put(hind,fnam);
                    //String line64=br.readLine().trim();
                    h64cnt.put(hind,Integer.parseInt(br.readLine().trim().substring(2)));
                    ArrayList<String> data=new ArrayList<>();
                    int datacnt=0;

                    while(datacnt<h64cnt.get(hind)){

                        data.add(br.readLine().trim());datacnt++;
                    }
                    h64val.put(hind,data);

                }

            }


        }
        else if(oct==128){
            String line="";
            int hind=0;
            while((line=br.readLine())!=null){
                if(line.trim().length()==0){
                    hind++;
                }
                else{

                    ArrayList<String> fnam=new ArrayList<>();
                    fnam.add(line.trim());
                    fnam.add(br.readLine().trim());
                    h128.put(hind,fnam);
                    h128cnt.put(hind,Integer.parseInt(br.readLine().trim().substring(2)));

                    ArrayList<String> data=new ArrayList<>();
                    int datacnt=0;

                    while(datacnt<h128cnt.get(hind)){

                        data.add(br.readLine().trim());
                        datacnt++;
                    }
                    h128val.put(hind,data);

                }

            }


        }
        else if(oct==256){
            String line="";
            int hind=0;
            while((line=br.readLine())!=null){
                if(line.trim().length()==0){
                    hind++;
                }
                else{

                    ArrayList<String> fnam=new ArrayList<>();
                    fnam.add(line.trim());
                    fnam.add(br.readLine().trim());
                    h256.put(hind,fnam);

                    h256cnt.put(hind,Integer.parseInt(br.readLine().trim().substring(2)));
                    ArrayList<String> data=new ArrayList<>();
                    int datacnt=0;

                    while(datacnt<h256cnt.get(hind)){

                        data.add(br.readLine().trim());
                        datacnt++;
                    }
                    h256val.put(hind,data);

                }

            }


        }




    }

    /*public static ArrayList<String> checkres(HashMap<Integer,ArrayList<String>> hx,HashMap<Integer,ArrayList<String>> hxval,HashMap<Integer,Integer> hxcnt){

        ArrayList<String> pn=new ArrayList<>();
        int tp=0;
        int tn=0;
        int fn=0;



    }*/

    public static boolean inducededgechk(int u,int v,HashMap<String,String> embedding,int cnt){

        for(int i:adjacenylist.keySet()){

            if(!adjacenylist.get(u).contains(i)){

                if(embedding.containsKey(i+"")){

                    int x=Integer.parseInt(embedding.get(i+""))+cnt;

                    String labelx=QueryU.get(i+"");
                    int y=v+cnt;
                    String labely=QueryU.get(u+"");
                    //System.out.println(x+" labelx: "+labelx);
                    //System.out.println(y+" labely: "+labely);

                    String qcry="Match (x:"+labelx+")--(y:"+labely+") where x.id="+x+" and y.id="+y+" return count(x) as p";
                    res = db.execute(qcry);
                    int val=0;
                    while(res.hasNext()){
                        Map<String,Object> obj=res.next();
                        //System.out.println(obj.get("p"));
                        val=Integer.parseInt(obj.get("p")+"");
                    }

                    if(val>0){
                        //cnu=2;
                        return false;
                    }


                }


            }


        }

        return true;


    }





    public static boolean edgechk(int u,int v,HashMap<String,String> embedding,int cnt){


        if(embedding.size()==0){
            //embedding.put(u+"",v+"");
            return true;
        }
        else{

            int cnu=0;
            //int cvu=0;
            for(int i:adjacenylist.get(u)){
                //System.out.println("embedding values: "+embedding.values());
                //System.out.println("embedding values contains: "+embedding.values().contains(v));

                if(embedding.keySet().contains(i+"")){

                    cnu=1;
                    int x=Integer.parseInt(embedding.get(i+""))+cnt;

                    String labelx=QueryU.get(i+"");
                    int y=v+cnt;
                    String labely=QueryU.get(u+"");
                    //System.out.println(x+" labelx: "+labelx);
                    //System.out.println(y+" labely: "+labely);

                    String qcry="Match (x:"+labelx+")--(y:"+labely+") where x.id="+x+" and y.id="+y+" return count(x) as p";
                    res = db.execute(qcry);
                    int val=0;
                    while(res.hasNext()){
                        Map<String,Object> obj=res.next();
                        //System.out.println(obj.get("p"));
                        val=Integer.parseInt(obj.get("p")+"");
                    }

                    if(val<=0){
                        cnu=2;
                        return false;
                    }
                    /*else{

                        cvu++;
                    }*/


                }

            }

            if(cnu==1){
                return true;
            }

        }

        return false;

    }


    public static ArrayList<Integer> getT1(HashMap<String,String> embed,int cnt){

        //need j...
        ArrayList<Integer> temp=new ArrayList<>();
        ArrayList<Integer> neighT1=new ArrayList<>();

        for(String s:embed.keySet()){

            temp.add(Integer.parseInt(embed.get(s)));
        }

        for(String s:embed.keySet()){

            String xval=s;
            String labelx=QueryU.get(xval);
            int x=Integer.parseInt(embed.get(s))+cnt;

            String qcry="Match (x:"+labelx+")--(y) where x.id="+x+" return y.id";
            res = db.execute(qcry);
            int val=0;
            while(res.hasNext()){
                Map<String,Object> obj=res.next();
                //System.out.println(obj.get("p"));
                val=Integer.parseInt(obj.get("y.id")+"")-cnt;

                if(!neighT1.contains(val)){

                    neighT1.add(val);

                }
            }

        }



        neighT1.removeAll(temp);

        return neighT1;





    }


    public static ArrayList<Integer> getT2(HashMap<String,String> embed,int cnt){

        //need i...
        ArrayList<Integer> temp=new ArrayList<>();
        ArrayList<Integer> neighT2=new ArrayList<>();


        for(String s:embed.keySet()){

            temp.add(Integer.parseInt(s));
        }

        for(String s :embed.keySet()){

            for(int i:adjacenylist.get(Integer.parseInt(s))){

                if(!neighT2.contains(i)){
                    neighT2.add(i);
                }

            }

        }

        neighT2.removeAll(temp);

        return neighT2;


    }


    public static ArrayList<Integer> getN1(HashMap<Integer,ArrayList<Integer>> candidates,HashMap<String,String> embed,ArrayList<Integer> T1){

        ArrayList<Integer> N1data=new ArrayList<>();
        ArrayList<Integer> temp=new ArrayList<>();

        for(String s:embed.keySet()){

            temp.add(Integer.parseInt(embed.get(s)));
        }



        for(int i:candidates.keySet()){

            for(int j:candidates.get(i)){


                if(!N1data.contains(j)){


                    N1data.add(j);
                }

            }
        }

        N1data.removeAll(temp);
        N1data.removeAll(T1);

        return N1data;




    }






    public static ArrayList<Integer> getN2(HashMap<Integer,ArrayList<Integer>> candidates,HashMap<String,String> embed,ArrayList<Integer> T2){

        ArrayList<Integer> N2data=new ArrayList<>();
        ArrayList<Integer> temp=new ArrayList<>();

        for(String s:embed.keySet()){

            temp.add(Integer.parseInt(s));
        }


        for(int i:candidates.keySet()){

            //for(int j:candidates.get(i)){


            if(!N2data.contains(i)){


                N2data.add(i);
            }

            //}
        }

        N2data.removeAll(temp);
        N2data.removeAll(T2);

        return N2data;




    }

    public static ArrayList<Integer> getCand(ArrayList<Integer> candilist,ArrayList<Integer> T1,HashMap<String,String> embedding){


        if(embedding.size()==0){

            return candilist;
        }
        else{
            //intersection...

            ArrayList<Integer> tempcandvalues=new ArrayList<>();

            for(int i:candilist){

                tempcandvalues.add(i);
            }


            tempcandvalues.retainAll(T1);

            return tempcandvalues;



        }


    }


    public static ArrayList<Integer> NeighboursOfV(int u,int v,int cnt){

        ArrayList<Integer> Vneigh=new ArrayList<>();

        String xval=u+"";
        String labelx=QueryU.get(xval);
        int x=v+cnt;

        String qcry="Match (x:"+labelx+")--(y) where x.id="+x+" return y.id";
        res = db.execute(qcry);
        int val=0;
        while(res.hasNext()){
            Map<String,Object> obj=res.next();
            //System.out.println(obj.get("p"));
            val=Integer.parseInt(obj.get("y.id")+"")-cnt;

            if(!Vneigh.contains(val)){

                Vneigh.add(val);

            }
        }


        return Vneigh;

    }



    public static ArrayList<Integer> NeighboursOfU(int u){

        ArrayList<Integer> Uneigh=new ArrayList<>();

        for(int i:adjacenylist.get(u)){

            if(!Uneigh.contains(i)){
                Uneigh.add(i);
            }


        }

        return Uneigh;
    }



    public static boolean rule1(int u,int v,HashMap<String,String> embed,int cnt,ArrayList<Integer> nv,ArrayList<Integer> nu){

        ArrayList<Integer> tempV=new ArrayList<>();
        ArrayList<Integer> neighV=new ArrayList<>();
        ArrayList<Integer> neiU=new ArrayList<>();

        ArrayList<Integer> tempU=new ArrayList<>();
        ArrayList<Integer> neighU=new ArrayList<>();
        ArrayList<Integer> neiV=new ArrayList<>();

        //System.out.println("nv: "+nv);
        //System.out.println("nu: "+nu);
        for(int i:nv){
            neighV.add(i);
            neiV.add(i);


        }

        for(int i:nu){

            neighU.add(i);
            neiU.add(i);

        }




        for(String s:embed.keySet()){

            tempV.add(Integer.parseInt(embed.get(s)));
        }

        for(String s:embed.keySet()){

            tempU.add(Integer.parseInt(s));
        }

      /*  String xval=u+"";
        String labelx=QueryU.get(xval);
        int x=v+cnt;

        String qcry="Match (x:"+labelx+")--(y) where x.id="+x+" and return y.id";
        res = db.execute(qcry);
        int val=0;
        while(res.hasNext()){
            Map<String,Object> obj=res.next();
            //System.out.println(obj.get("p"));
            val=Integer.parseInt(obj.get("y.id")+"")-cnt;

            if(!neighV.contains(val)){

                neighV.add(val);
                neiV.add(val);

            }
        }*/

        tempV.retainAll(neighV);

       /* for(int i:adjacenylist.get(u)){

            if(!neiU.contains(i)){
                neiU.add(i);
                neighU.add(i);
            }


        }*/

        //System.out.println("tempV: "+tempV);


        int count=0;
        for(int i:tempV){
            count=0;
            for(int j:neiU){

                if(embed.get(j+"")!=null && (i==Integer.parseInt(embed.get(j+""))) ){
                    count=1;
                    break;


                }


            }

            if(count==0){

                return false;
            }


        }


        //part2....



        tempU.retainAll(neighU);
        //System.out.println("tempU: "+tempU);
        //System.out.println(embed);
        //System.out.println("neiV: "+neiV);
        count=0;
        for(int i:tempU){

            count=0;
            if( embed.get(i+"")!=null &&  (neiV.contains(Integer.parseInt(embed.get(i+""))))  ){
                count=1;
            }

            if(count==0){

                return false;
            }


        }




        return true;






    }



    public static boolean rule2(ArrayList<Integer> T1,ArrayList<Integer> T2,ArrayList<Integer> nv,ArrayList<Integer> nu){



        ArrayList<Integer> neighV=new ArrayList<>();



        ArrayList<Integer> neighU=new ArrayList<>();


        for(int i:nv){
            neighV.add(i);

        }

        for(int i:nu){

            neighU.add(i);


        }


        neighV.retainAll(T1);
        neighU.retainAll(T2);


        if(neighV.size()>=neighU.size()){

            return true;
        }


        return false;





    }



    //rule3....


    public static boolean rule3(ArrayList<Integer> N1,ArrayList<Integer> N2,ArrayList<Integer> nv,ArrayList<Integer> nu){



        ArrayList<Integer> neighV=new ArrayList<>();



        ArrayList<Integer> neighU=new ArrayList<>();


        for(int i:nv){
            neighV.add(i);

        }

        for(int i:nu){

            neighU.add(i);


        }


        neighV.retainAll(N1);
        neighU.retainAll(N2);


        if(neighV.size()>=neighU.size()){

            return true;
        }


        return false;





    }











    public static boolean rules(int u,int v,HashMap<String,String> embed,int cnt,ArrayList<Integer> T1,ArrayList<Integer> T2,ArrayList<Integer> N1, ArrayList<Integer> N2){

        if(embed.size()==0){
            return true;
        }
        else{

            ArrayList<Integer> neighboursV=NeighboursOfV(u,v,cnt);
            ArrayList<Integer> neighboursU=NeighboursOfU(u);



            //rule123...
            boolean r1=rule1(u,v,embed,cnt,neighboursV,neighboursU);
            boolean r2=rule2(T1,T2,neighboursV,neighboursU);
            boolean r3=rule3(N1,N2,neighboursV,neighboursU);

            //System.out.println(r1+" "+r2+" "+r3);

            if(r1 && r2 && r3){

                return true;
            }



        }

        return false;


    }










    public static void subgraphsearch(int x, HashMap<Integer,ArrayList<Integer>> candidates,HashMap<String,String> embedding,int[] pt,int cnt){

        if(embedding.size()==adjacenylist.size()){


            TreeMap<String,String> outtree=new TreeMap<>();

            for(String st:embedding.keySet()){

                outtree.put(st,embedding.get(st));
            }



            String eco = "";
            eco = eco + "S:" + hglob.size() + ":";
            for(String sm:outtree.keySet()){



                eco=eco+sm+","+outtree.get(sm)+";";
            }

            eco=eco.substring(0,eco.length()-1);
            //System.out.println(eco);
            subgoutput.add(eco);

        }
        else{

            outer:for(int i=x;i<pt.length;i++){

                ArrayList<Integer> T1=new ArrayList<>();
                ArrayList<Integer> T2=new ArrayList<>();
                ArrayList<Integer> N1=new ArrayList<>();
                ArrayList<Integer> N2=new ArrayList<>();
                if(embedding.size()>0){

                    T1= getT1(embedding,cnt);

                    T2= getT2(embedding,cnt);
                    N1= getN1(candidates,embedding,T1);
                    N2=getN2(candidates,embedding,T2);
                    //System.out.println("T1: "+T1);
                    //System.out.println("T2: "+T2);
                    //System.out.println("N1: "+N1);
                    //System.out.println("N2: "+N2);
                }


                if(!embedding.keySet().contains(pt[i]+"")){




                    //getCand(candidates.get(i),T1,embedding)
                    for(int j: getCand(candidates.get(pt[i]),T1,embedding)){

                        if(!embedding.containsValue(j+"")) {

                            //System.out.println("i: " + i + " j: " + j );
                            if (rules(pt[i], j, embedding, cnt,T1,T2,N1,N2)) {

                                // if(inducededgechk(i,j,embedding,cnt)) {
                                embedding.put(pt[i] + "", j + "");
                                   /* if(subgoutput.size()==22) {
                                        System.out.println("embedding val: " + embedding);
                                    }*/
                                subgraphsearch(x + 1, candidates, embedding, pt, cnt);
                                if(subloopbreak==1) break outer;
                                embedding.remove(pt[i] + "");
                                // }
                            }
                        }

                    }


                }

                if(i==0){
                    subloopbreak=1;
                }


            }


        }


    }





    public static void main(String args[]) throws Exception{


        try {
            File fold = new File("G:\\sem3\\graph _db\\protiensDB\\Proteins\\Proteins\\query");
            File[] allfiles = fold.listFiles();

            File foldtar = new File("G:\\sem3\\graph _db\\protiensDB\\Proteins\\Proteins\\target");
            File[] allfilestar = foldtar.listFiles();

            File foldGT = new File("G:\\sem3\\graph _db\\protiensDB\\Proteins\\Proteins\\ground_truth");
            File[] allfilesGT = foldGT.listFiles();

            /*GraphDatabaseFactory dbFactory = new GraphDatabaseFactory();
            db = dbFactory.newEmbeddedDatabase(new File("ProtiensNeoNewID"));*/

            Path finalfile= Paths.get("vf2induced.txt");




            h8.clear();
            h8cnt.clear();
            h8val.clear();
            h16.clear();
            h16cnt.clear();
            h16val.clear();
            h32.clear();
            h32cnt.clear();
            h32val.clear();
            h64.clear();
            h64cnt.clear();
            h64val.clear();
            h128.clear();
            h128cnt.clear();
            h128val.clear();
            h256.clear();
            h256cnt.clear();
            h256val.clear();

            String[] tname = new String[allfilestar.length];
            String lt = "";

            for (int i = 0; i < allfilestar.length; i++) {
                tname[i] = "_" + allfilestar[i].getName().substring(0, allfilestar[i].getName().length() - 4);
                //System.out.println(tname[i]);
            }

            for (int i = 0; i < allfilesGT.length; i++) {
                String[] spgt = allfilesGT[i].getName().split("\\.");
                //System.out.println("get: " + spgt[1]);
                //System.out.println(allfilesGT[i]);
                fillGT(allfilesGT[i].toString(), Integer.parseInt(spgt[1]));
            }

            int[] filecount={8,16,32,64,128,256};

            for(int kman=0;kman<filecount.length;kman++) {

                for (int i = 0; i < allfiles.length; i++) {

                    dfsrun=0;
                    path=new ArrayList<>();

                    String[] sfn=allfiles[i].getName().trim().split("\\.");
                    if(Integer.parseInt(sfn[1])!=filecount[kman]){
                        continue;
                    }

                    System.out.println(allfiles[i].getName());
                    BufferedReader br = new BufferedReader(new FileReader(allfiles[i]));
                    //BufferedReader br = new BufferedReader(new FileReader("G:\\sem3\\graph _db\\protiensDB\\Proteins\\Proteins\\query\\backbones_198L.8.sub.grf"));
                    String line = "";
                    String fq = "";
                    while ((line = br.readLine()) != null) {

                        fq = fq + line + '\n';


                    }

                    int cntr = 40000;
                    int index = 1;


                    //looping each target...
                    for (int j = 0; j < tname.length; j++) {
                        int countTot = 0;
                        System.out.println(tname[j]);

                        HashMap<Integer,ArrayList<Integer>> DataV=new HashMap<>();

                        ArrayList<String> cypqrylist = parser(fq, tname[j]);

                        //System.out.println(cypqry);

                        long starttym = System.currentTimeMillis();


                        ArrayList<String> qout = new ArrayList<>();


                        int nvalct=0;
                        for(String cypqry:cypqrylist) {

                            //System.out.println(cypqry);
                            res = db.execute(cypqry);


                            //System.out.println("value found...");
                            ArrayList<Integer> aobj=new ArrayList<>();


                            while (res.hasNext()) {
                                Map<String, Object> obj = res.next();
                                //aobj.add(obj.get("n"+nvalct));
                                //System.out.println(obj.get("G"));
                                /*eco = "";
                                eco = eco + "S:" + hglob.size() + ":";
                                for (String sg : hglob.keySet()) {
                                    eco = eco + sg + "," + (Integer.parseInt(obj.get(hglob.get(sg)) + "") - cntr) + ";";


                                }
                                qout.add(eco.substring(0, eco.length() - 1));*/
                                //countTot++;
                                aobj.add(Integer.parseInt(obj.get("n"+nvalct+".id")+"")-cntr);
                            }

                            DataV.put(nvalct,aobj);
                            nvalct++;

                        }


                        int minstart=0;
                        int min=DataV.get(0).size();
                        for(int x:DataV.keySet()){
                            System.out.print(x+" ");
                            System.out.println(DataV.get(x));
                            System.out.println(DataV.get(x).size());
                            if(DataV.get(x).size()<min){
                                min=DataV.get(x).size();
                                minstart=x;
                            }
                        }


                        path=new ArrayList<>();
                        DFS(minstart, adjacenylist);

                        System.out.println("path: "+path);


                        subgoutput=new ArrayList<>();

                        int[] mydfspath=new int[path.size()];
                        int index1=0;
                        for(int q:path){
                            mydfspath[index1]=q;index1++;


                        }


                        subloopbreak=0;
                        subgraphsearch(0,DataV,new HashMap<>(),mydfspath,cntr);

                        /*String eco = "";
                        eco = eco + "S:" + hglob.size() + ":";
                        for(String sm:subgoutput.keySet()){



                            eco=eco+sm+","+subgoutput.get(sm)+";";
                        }*/

                        qout = subgoutput;

                        long timetaken = System.currentTimeMillis() - starttym;

                        System.out.println("T:" + tname[j].substring(1) + ".grf");
                        System.out.println("P:" + allfiles[i].getName());
                        System.out.println("N:" + qout.size());

                        // printing my results...
                        for (String sf : qout) {
                            System.out.println(sf);
                        }


                        String ts = "T:" + tname[j].substring(1) + ".grf";
                        String ps = "P:" + allfiles[i].getName();
                        ArrayList<String> pn = new ArrayList<>();
                        if (hglob.size() == 8) {


                            int tp = 0;
                            int fp = 0;
                            int fn = 0;
                            int getval = 0;
                            for (int x : h8.keySet()) {


                                if (ts.equals(h8.get(x).get(0)) && ps.equals(h8.get(x).get(1))) {

                                    getval = x;
                                    break;
                                }


                            }

                            //  if(countTot>=h8cnt.get(getval)){

                            //System.out.println("h8val: ");
                            //System.out.println(h8val.get(getval));

                            for (String s : qout) {

                                if (h8val.get(getval).contains(s)) {


                                    tp++;

                                } else {

                                    fp++;
                                    //System.out.println("not in : "+s);
                                }

                            }

                            for (String s : h8val.get(getval)) {

                                if (!qout.contains(s)) {


                                    fn++;

                                }


                            }
                            System.out.println("in GT: " + h8.get(getval));

                            // }
                            pn.add("TP: " + tp);
                            pn.add("FP: " + fp);
                            pn.add("FN: " + fn);


                        } else if (hglob.size() == 16) {


                            int tp = 0;
                            int fp = 0;
                            int fn = 0;
                            int getval = 0;
                            for (int x : h16.keySet()) {


                                if (ts.equals(h16.get(x).get(0)) && ps.equals(h16.get(x).get(1))) {

                                    getval = x;
                                    break;
                                }


                            }

                            //  if(countTot>=h8cnt.get(getval)){


                            for (String s : qout) {

                                if (h16val.get(getval).contains(s)) {


                                    tp++;

                                } else {

                                    fn++;
                                }

                            }

                            for (String s : h16val.get(getval)) {

                                if (!qout.contains(s)) {


                                    fp++;

                                }


                            }

                            // }
                            pn.add("TP: " + tp);
                            pn.add("FP: " + fp);
                            pn.add("FN: " + fn);


                        } else if (hglob.size() == 32) {


                            int tp = 0;
                            int fp = 0;
                            int fn = 0;
                            int getval = 0;
                            for (int x : h32.keySet()) {


                                if (ts.equals(h32.get(x).get(0)) && ps.equals(h32.get(x).get(1))) {

                                    getval = x;
                                    break;
                                }


                            }

                            //  if(countTot>=h8cnt.get(getval)){


                            for (String s : qout) {

                                if (h32val.get(getval).contains(s)) {


                                    tp++;

                                } else {

                                    fn++;
                                }

                            }

                            for (String s : h32val.get(getval)) {

                                if (!qout.contains(s)) {


                                    fp++;

                                }


                            }

                            // }
                            pn.add("TP: " + tp);
                            pn.add("FP: " + fp);
                            pn.add("FN: " + fn);


                        } else if (hglob.size() == 64) {


                            int tp = 0;
                            int fp = 0;
                            int fn = 0;
                            int getval = 0;
                            for (int x : h64.keySet()) {


                                if (ts.equals(h64.get(x).get(0)) && ps.equals(h64.get(x).get(1))) {

                                    getval = x;
                                    break;
                                }


                            }

                            //  if(countTot>=h8cnt.get(getval)){


                            for (String s : qout) {

                                if (h64val.get(getval).contains(s)) {


                                    tp++;

                                } else {

                                    fn++;
                                }

                            }

                            for (String s : h64val.get(getval)) {

                                if (!qout.contains(s)) {


                                    fp++;

                                }


                            }

                            // }
                            pn.add("TP: " + tp);
                            pn.add("FP: " + fp);
                            pn.add("FN: " + fn);


                        } else if (hglob.size() == 128) {


                            int tp = 0;
                            int fp = 0;
                            int fn = 0;
                            int getval = 0;
                            for (int x : h128.keySet()) {


                                if (ts.equals(h128.get(x).get(0)) && ps.equals(h128.get(x).get(1))) {

                                    getval = x;
                                    break;
                                }


                            }

                            //  if(countTot>=h8cnt.get(getval)){


                            for (String s : qout) {

                                if (h128val.get(getval).contains(s)) {


                                    tp++;

                                } else {

                                    fn++;
                                }

                            }

                            for (String s : h128val.get(getval)) {

                                if (!qout.contains(s)) {


                                    fp++;

                                }


                            }

                            // }
                            pn.add("TP: " + tp);
                            pn.add("FP: " + fp);
                            pn.add("FN: " + fn);


                        } else if (hglob.size() == 256) {


                            int tp = 0;
                            int fp = 0;
                            int fn = 0;
                            int getval = 0;
                            for (int x : h256.keySet()) {


                                if (ts.equals(h256.get(x).get(0)) && ps.equals(h256.get(x).get(1))) {

                                    getval = x;
                                    break;
                                }


                            }

                            //  if(countTot>=h8cnt.get(getval)){


                            for (String s : qout) {

                                if (h256val.get(getval).contains(s)) {


                                    tp++;

                                } else {

                                    fn++;
                                }

                            }

                            for (String s : h256val.get(getval)) {

                                if (!qout.contains(s)) {


                                    fp++;

                                }


                            }

                            // }
                            pn.add("TP: " + tp);
                            pn.add("FP: " + fp);
                            pn.add("FN: " + fn);


                        }


                        System.out.println("result analysis...");
                        System.out.println(pn);
                        System.out.println("Time: " + timetaken);
                        System.out.println();


                        ArrayList<String> findat=new ArrayList<>();
                        findat.add(ts);
                        findat.add(ps);
                        findat.add("result analysis...");
                        findat.add(pn.toString());
                        findat.add("Time: "+timetaken);
                        findat.add("");
                        Files.write(finalfile,findat, StandardOpenOption.APPEND);

                        res.close();


                        cntr = cntr + 10000 * index;
                        index++;

                        //break;
                    }

                    break;


                }

                break;

            }
            db.shutdown();
        }
        catch(Exception e){
            if(db!=null)
                db.shutdown();

            e.printStackTrace();
        }
    }
}
