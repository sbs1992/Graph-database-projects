package org.protiens;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.neo4j.graphalgo.LouvainProc;
import org.neo4j.graphalgo.UnionFindProc;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Result;
import org.neo4j.graphdb.factory.GraphDatabaseFactory;
import org.neo4j.internal.kernel.api.exceptions.KernelException;
import org.neo4j.kernel.impl.proc.Procedures;
import org.neo4j.kernel.internal.GraphDatabaseAPI;

public class KInfluentialCommunitySearch {
	
private static String DBPath = "KCore";
	
	private static GraphDatabaseFactory dbFactory;
	private static GraphDatabaseService dbService;
	
	public static void connectToDB()
	{
		dbFactory = new GraphDatabaseFactory();
		dbService = dbFactory.newEmbeddedDatabase(new File(DBPath));
	}
	
	public static void executeShutdown()
	{
		dbService.shutdown();
	}
	
	public static List<Integer> findNeighbours(long id)
	{
		List<Integer> neighboursList = new ArrayList<>();
		
		String query = "MATCH (N1)--(N2) WHERE ID(N1)="+id+" RETURN DISTINCT N2";
		
		Result rs = dbService.execute(query);
		
		while(rs.hasNext())
		{
			Map<String,Object> next = rs.next();
			for(Entry<String, Object> entry : next.entrySet())
			{
				if(entry.getKey().equals("N2"))
				{
					String node = entry.getValue().toString();
					int nodeId = Integer.parseInt(node.substring(5, node.length()-1));
					neighboursList.add(nodeId);
				}
			}
		}
		rs.close();
		Collections.sort(neighboursList);
		return neighboursList;
	}
	
	public static List<Integer> getALlNodesFromGraph()
	{
		List<Integer> nodesList = new ArrayList<>();
		
		String query = "MATCH (N1) RETURN N1";
		
		Result rs = dbService.execute(query);
		
		while(rs.hasNext())
		{
			Map<String,Object> next = rs.next();
			for(Entry<String, Object> entry : next.entrySet())
			{
				String node = entry.getValue().toString();
				int nodeId = Integer.parseInt(node.substring(5, node.length()-1));
				nodesList.add(nodeId);
				
			}
		}
		rs.close();
		return nodesList;
	}
	
	public static Map<Integer,List<Integer>> getAdjacencyList()
	{
		String query = "MATCH (N1)-[:HASCONNECTION]-(N2) \n" + 
				"RETURN N1.id, Collect(N2.id) as neighbours;";
		Map<Integer,List<Integer>> adjacencyList = new HashMap<>();
		
		Result rs = dbService.execute(query);
		
		while(rs.hasNext())
		{
			Map<String,Object> next = rs.next();
			int nodeId = (int)next.get("N1.id");
			List<Integer> neighbours = (List<Integer>) next.get("neighbours");
			adjacencyList.put(nodeId, neighbours);
		}
		//System.out.println(adjacencyList);
		return adjacencyList;
	}
	
	public static void deleteNodesAfterFindingKCoreNodes(List<Integer> nodesList, int batchSize)
	{
		System.out.println("Total Nodes to be delete"+nodesList.size());
		while(!nodesList.isEmpty())
		{
			List<Integer> sublist = null;
			if(nodesList.size()<batchSize)
				sublist = nodesList.subList(0, nodesList.size());
			else
				sublist = nodesList.subList(0, batchSize);
			System.out.println("Nodes being deleted:"+sublist);
			
			/*String deleteQuery = "call apoc.periodic.iterate(\"MATCH (n) where id(n) in "+ nodesList.toString() +" return n\", \"DETACH DELETE n\", {batchSize:100, parallel:true})\n" + 
					"yield batches, total return batches, total";*/
			
			String deleteQuery = "MATCH (N1)\n" + 
			"WHERE ID(N1) in "+sublist.toString()+"\n" + 
			"DETACH DELETE N1";
			
			Result rs = dbService.execute(deleteQuery);
			while(rs.hasNext())
			{
				Map<String,Object> next = rs.next();
				for(Entry<String, Object> entry : next.entrySet())
				{
					System.out.println(entry.getKey()+":"+entry.getValue());
				}
			}
			rs.close();
			nodesList.removeAll(sublist);
		}
		
		
		/*for(int nodeToDelete : nodesList)
		{
			String query = "MATCH (N1) WHERE ID(N1)="+nodeToDelete+" DETACH DELETE N1";
			Result rs = dbService.execute(query);
			while(rs.hasNext())
			{
				Map<String,Object> next = rs.next();
				for(Entry<String, Object> entry : next.entrySet())
				{
					System.out.println(entry.getKey()+":"+entry.getValue());
				}
			}
			rs.close();
			deleteNode(nodeToDelete);
		}*/
	}
	
	public static void deleteNode(int nodeId)
	{
		String query = "MATCH (N1) WHERE ID(N1)="+nodeId+" DETACH DELETE N1";
		Result rs = dbService.execute(query);
		while(rs.hasNext())
		{
			Map<String,Object> next = rs.next();
			for(Entry<String, Object> entry : next.entrySet())
			{
				//System.out.println(entry.getKey()+":"+entry.getValue());
			}
		}
		rs.close();
	
	}
	
	public static void basicAlgorithm() throws KernelException, IOException
	{
		int k_value = 3;
		int batchSize = 1000;
				
		List<List<Integer>> H_k = new ArrayList<>();
		System.out.println("Getting Adjacency List");
		Map<Integer,List<Integer>> graph = getAdjacencyList();
		System.out.println("Adjacency List fetched..");
		KCore k = new KCore();
		k.graph = graph;
		System.out.println("Find K-Cores");
		List<Integer> nodesToDelete = k.printKCores(k_value);
		System.out.println("Find K-Cores complete");
		
		System.out.println("Delete Nodes after K-Cores..");
		deleteNodesAfterFindingKCoreNodes(nodesToDelete, batchSize);
		System.out.println("Delete Nodes after K-Cores complete");
		
		System.out.println("Find Connected Components");
		Map<Integer, List<Integer>> conntectedComponnents =  findConnectedComponnents();
		System.out.println("Find Connected Components complete");
		
		while(!conntectedComponnents.isEmpty())
		{
			System.out.println("Find MCC with lowest i value..");
			MaximalConnectedComponent lowestInfluenceValueMCC = findMCCWithLowestInfluenceValue(conntectedComponnents);
			System.out.println("Find MCC with lowest i values complete");
			System.out.println(lowestInfluenceValueMCC.connectedComponent.toString());
			System.out.println("Find MCC with lowest i values complete");
			
			Collections.sort(lowestInfluenceValueMCC.connectedComponent);
			H_k.add(lowestInfluenceValueMCC.connectedComponent);
			System.out.println("Community:"+lowestInfluenceValueMCC.connectedComponent);
			
			int u = lowestInfluenceValueMCC.influenceValue;
			
			System.out.println("Delete node with smallest i value..");
			deleteNode(u);
			System.out.println("Node"+u+"deleted..");
			
			System.out.println("Getting Adjacency List");
			graph = getAdjacencyList();
			System.out.println("Adjacency List fetched..");
			k.graph = graph;
			
			System.out.println("Find K-Cores");
			nodesToDelete = k.printKCores(k_value);
			System.out.println("Find K-Cores complete");
			
			System.out.println("Delete Nodes after K-Cores..");
			deleteNodesAfterFindingKCoreNodes(nodesToDelete, batchSize);
			System.out.println("Delete Nodes after K-Cores complete");
			
			System.out.println("Find Connected Components");
			conntectedComponnents =  findConnectedComponnents();
			System.out.println("Find Connected Components complete");
		}
		
		//System.out.println("Top Results"+H_k);
		System.out.println("Top Results Size"+H_k.size());
		for(List<Integer> comm: H_k)
			System.out.println(comm);
	}
	
	private static MaximalConnectedComponent findMCCWithLowestInfluenceValue(Map<Integer, List<Integer>> conntectedComponnents) {
		// TODO Auto-generated method stub
		Map<Integer, Integer> connectedComponentsInfluenceValues = new HashMap<>();
		for(Entry<Integer, List<Integer>> e : conntectedComponnents.entrySet())
		{
			int lowestNodeValue = Collections.min(e.getValue());
			connectedComponentsInfluenceValues.put(e.getKey(), lowestNodeValue);
		}
		int minValue = Integer.MAX_VALUE;
		int setValue = -1;
		for(Entry<Integer, Integer> e : connectedComponentsInfluenceValues.entrySet())
		{
			if(e.getValue()<minValue){
				minValue = e.getValue();
				setValue = e.getKey();
			}
		}
		MaximalConnectedComponent mcc = new MaximalConnectedComponent();
		mcc.connectedComponent = conntectedComponnents.get(setValue);
		mcc.influenceValue = minValue;
		return mcc;
	}

	public static List<Integer> checkData()
	{
		List<Integer> nodesList = new ArrayList<>();
		
		String query = "MATCH (N1) RETURN COUNT (N1);";
		
		//String query = "MATCH (N) \n" + 
				//"RETURN N.id, size( (N)-[:link]-()) as edgeCount;";
		
		/*String query = "MATCH (N1)-[:link]-(N2) WHERE ID(N1)=0 \n" + 
				"RETURN N1.id, Collect(N2.id) as neighbours LIMIT 100;";*/
		
		Result rs = dbService.execute(query);
		
		while(rs.hasNext())
		{
			Map<String,Object> next = rs.next();
			for(Entry<String, Object> entry : next.entrySet())
			{
				System.out.println(entry.getKey()+":"+entry.getValue());
			}
		}
		rs.close();
		return nodesList;
	}
	
	public static Map<Integer,List<Integer>> findConnectedComponnents() throws KernelException
	{
		Map<Integer,List<Integer>> connectedComponents = new HashMap<>();
		
		String query = "CALL algo.unionFind.stream('V', 'HASCONNECTION', {})\n" + 
				"YIELD nodeId,setId\n" + 
				"\n" + 
				"RETURN nodeId, setId";
		
		Result rs = dbService.execute(query);
		
		while(rs.hasNext())
		{
			Map<String,Object> next = rs.next();
			Integer nodeId = null,setId = null;
			for(Entry<String, Object> entry : next.entrySet())
			{
				//System.out.println(entry.getKey()+":"+entry.getValue());
				if(entry.getKey().equals("nodeId"))
				{
					nodeId = Integer.parseInt(entry.getValue().toString());
				}
				else if(entry.getKey().equals("setId"))
				{
					setId = Integer.parseInt(entry.getValue().toString());
				}
			}
			List<Integer> componentList = null;
			if(connectedComponents.containsKey(setId))
			{
				componentList = connectedComponents.get(setId);
				componentList.add(nodeId);
			}
			else
			{
				componentList = new ArrayList<>();
				componentList.add(nodeId);
				connectedComponents.put(setId, componentList);
			}
			
		}
		rs.close();
		//System.out.println(connectedComponents.size());
		for(Entry<Integer,List<Integer>> e: connectedComponents.entrySet())
		{
			System.out.println(e.getValue());
		}
		return connectedComponents;
	}

	private static void registerProcedures() throws KernelException {
		Procedures procedures = ((GraphDatabaseAPI) dbService).getDependencyResolver().resolveDependency(Procedures.class);

		procedures.registerProcedure(UnionFindProc.class);
		
		procedures.registerProcedure(LouvainProc.class);
	}
	
	private static void getCommunitiesByLouvainAlgo()
	{
		String query = "CALL algo.louvain('mynode', 'link',\n" + 
				"  {write:true, writeProperty:'community'})\n" + 
				"YIELD nodes, communityCount, iterations, loadMillis, computeMillis, writeMillis;";
		
		Result rs = dbService.execute(query);
		while(rs.hasNext())
		{
			Map<String,Object> next = rs.next();
			for(Entry<String, Object> entry : next.entrySet())
			{
				System.out.println(entry.getKey()+":"+entry.getValue());
			}
		}
		rs.close();
	}
	
	public static void main(String[] args) throws KernelException, IOException {
		// TODO Auto-generated method stub
		long starttime = System.currentTimeMillis(); 
		connectToDB();
		registerProcedures();
		//findConnectedComponnents();
		//checkData();
		basicAlgorithm();
		//getAdjacencyList();
		//getCommunitiesByLouvainAlgo();
		executeShutdown();
		System.out.println("Total time taken:"+(System.currentTimeMillis() - starttime));
	}

}


class MaximalConnectedComponent
{
	List<Integer> connectedComponent;
	int influenceValue;
}
