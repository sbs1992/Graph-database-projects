import org.apache.commons.io.FileUtils;
import org.neo4j.graphalgo.PageRankProc;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Label;
import org.neo4j.graphdb.RelationshipType;
import org.neo4j.graphdb.Result;
import org.neo4j.graphdb.factory.GraphDatabaseFactory;
import org.neo4j.graphdb.factory.GraphDatabaseSettings;
import org.neo4j.kernel.impl.proc.Procedures;
import org.neo4j.kernel.internal.GraphDatabaseAPI;
import org.neo4j.unsafe.batchinsert.BatchInserter;
import org.neo4j.unsafe.batchinsert.BatchInserters;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Weights {

    public static ArrayList<Integer> nodelist=new ArrayList<>();
    public static ArrayList<Double> rankist=new ArrayList<>();
    public static HashMap<Integer,ArrayList<Integer>> relationshipMapInfo=new HashMap<>();
    public static HashMap<Integer,ArrayList<Integer>> relationshipMapInfoCore=new HashMap<>();
    public static HashMap<Integer,Double> noderankmap=new HashMap<>();
    public static HashMap<Integer,Integer> nodecoremap=new HashMap<>();
    public static ArrayList<Integer> delnodes=new ArrayList<>();
    //public static ArrayList<Integer> nodes=new ArrayList<>();
    public static HashMap<Integer,Integer> relationcount=new HashMap<>();
    public static int first_tym=0;
    public static int core=0;



    public static void deletedata(int val){

        relationshipMapInfoCore.remove(new Integer(val));

    /*    for(int i:relationshipMapInfoCore.keySet()){

            if(relationshipMapInfoCore.get(i).contains(val)){
                relationshipMapInfoCore.get(i).remove(new Integer(val));
            }
        }*/

    }

    public static void dfscore(ArrayList<Integer> nlist){


        for(int nd:nlist){

            if(!relationshipMapInfoCore.keySet().contains(nd)) {
                continue;
            }
            else{

                if(relationcount.get(nd)<=core){
                    //delnodes.add(nd);
                    nodecoremap.put(nd,core);
                    ArrayList<Integer> neighbours=new ArrayList<>();
                    for(int ng:relationshipMapInfoCore.get(nd)){
                        neighbours.add(ng);
                        relationcount.put(ng,relationcount.get(ng)-1);
                    }
                    deletedata(nd);
                    dfscore(neighbours);

                }


            }



        }


    }

    public static boolean checkRankContainment(double rank) throws Exception{


        if(rankist.contains(rank)){
            return true;
        }
        rankist.add(rank);
        return false;

    }

    public static boolean checkNodeContainment(int node) throws Exception{


        if(nodelist.contains(node)){
            return true;
        }
        nodelist.add(node);
        return false;

    }


    public static void createDB(BatchInserter bi,String database) throws Exception{


        bi = BatchInserters.inserter(new File(database));

        BufferedReader br=new BufferedReader(new FileReader("testdata.txt"));

        //BufferedReader br=new BufferedReader(new FileReader("connections.txt"));

        if(first_tym>0){

            //System.out.println(relationshipMapInfo);
            System.out.println();
            //System.out.println(noderankmap);
        }

        String line="";

        //create nodes and relationships...
        while((line=br.readLine())!=null) {

            if (line.trim().charAt(0) == '#') continue;

            String[] sp = line.trim().split(" +");
            int n1 = Integer.parseInt(sp[0]);
            int n2 = Integer.parseInt(sp[1]);

            if(first_tym==0){
                if (!relationshipMapInfo.containsKey(n1)) {
                    ArrayList<Integer> n1_relations = new ArrayList<>();
                    n1_relations.add(n2);
                    relationshipMapInfo.put(n1, n1_relations);

                } else {

                    if (!relationshipMapInfo.get(n1).contains(n2)) {
                        relationshipMapInfo.get(n1).add(n2);
                    }
                }

                if (!relationshipMapInfo.containsKey(n2)) {
                    ArrayList<Integer> n2_relations = new ArrayList<>();
                    n2_relations.add(n1);
                    relationshipMapInfo.put(n2, n2_relations);

                } else {
                    if (!relationshipMapInfo.get(n2).contains(n1)) {
                        relationshipMapInfo.get(n2).add(n1);
                    }
                }



            }

            if(!checkNodeContainment(n1)){
                if(first_tym==0) {
                    Map<String, Object> hmap = new HashMap<>();
                    hmap.put("id", n1);
                    hmap.put("weight", 0);
                    hmap.put("corevalue",-1);
                    hmap.put("relation_count", 0);
                    hmap.put("relations", "");
                    bi.createNode(n1, hmap, Label.label("mynode"));
                }
                else{
                    Map<String, Object> hmap = new HashMap<>();
                    hmap.put("id", n1);

                    if(!checkRankContainment(noderankmap.get(n1))) {

                        hmap.put("weight", noderankmap.get(n1));
                        //hmap.put("weight",n1);
                    }
                    else{

                        hmap.put("weight",n1);
                    }
                    hmap.put("corevalue",nodecoremap.get(n1));
                    hmap.put("relation_count", relationshipMapInfo.get(n1).size());
                    hmap.put("relations", relationshipMapInfo.get(n1).toString());
                    bi.createNode(n1, hmap, Label.label("mynode"));
                }

            }

            if(!checkNodeContainment(n2)){
                if(first_tym==0) {
                    Map<String, Object> hmap = new HashMap<>();
                    hmap.put("id", n2);
                    hmap.put("weight", 0);
                    hmap.put("corevalue",-1);
                    hmap.put("relation_count", 0);
                    hmap.put("relations", "");
                    bi.createNode(n2, hmap, Label.label("mynode"));
                }
                else{
                    Map<String, Object> hmap = new HashMap<>();
                    hmap.put("id", n2);

                    if(!checkRankContainment(noderankmap.get(n2))) {

                        hmap.put("weight", noderankmap.get(n2));
                        //hmap.put("weight",n2);
                    }
                    else{

                        hmap.put("weight",n2);
                    }

                    hmap.put("corevalue",nodecoremap.get(n2));
                    hmap.put("relation_count", relationshipMapInfo.get(n2).size());
                    hmap.put("relations", relationshipMapInfo.get(n2).toString());
                    bi.createNode(n2, hmap, Label.label("mynode"));

                }

            }


            bi.createRelationship(n1,n2, RelationshipType.withName("link"),new HashMap<>());


        }

        first_tym++;



        if(bi!=null)
            bi.shutdown();

        System.out.println("DB created...");

    }


    public static void main(String[] args) throws Exception{


        BatchInserter bi=null;
        Result rs=null;
        GraphDatabaseService gds=null;
        try {


            createDB(bi,"MyGraphDBTest");
            System.out.println("calculating pagerank and updating the DB");




            ArrayList<Integer> nodes=new ArrayList<>();

            for(int n:relationshipMapInfo.keySet()){

                ArrayList<Integer> al=new ArrayList<>();
                for(int a:relationshipMapInfo.get(n)){
                    al.add(a);
                }
                nodes.add(n);
                relationshipMapInfoCore.put(n,al);
                relationcount.put(n,al.size());

            }


            System.out.println("copy done...");

            GraphDatabaseService data = new GraphDatabaseFactory()

                    .newEmbeddedDatabaseBuilder(new File("MyGraphDBTest"))

                    .setConfig(GraphDatabaseSettings.pagecache_memory, "6144M" )

                    .setConfig(GraphDatabaseSettings.string_block_size, "60" )

                    .setConfig(GraphDatabaseSettings.array_block_size, "300" )

                    .newGraphDatabase();



            Procedures procedures = ((GraphDatabaseAPI) data).getDependencyResolver().resolveDependency(Procedures.class);

            procedures.registerProcedure(PageRankProc.class);



            rs=data.execute(
                    " call algo.pageRank.stream('mynode','') yield node, score" +
                            " return node.id, score ");

            while(rs.hasNext()){

                Map<String,Object> nxt=rs.next();
                int nodeid=Integer.parseInt(nxt.get("node.id")+"");

                double rank=Double.parseDouble(nxt.get("score")+"");

                noderankmap.put(nodeid,rank);



            }

            System.out.println("rank calculated..calculating core numbers..");

            //cal corenumbers...

            while(relationshipMapInfoCore.size()>0){

                dfscore(nodes);
                core++;


            }


            System.out.println("cores found...");
            //System.out.println(nodecoremap);

            nodelist=new ArrayList<>();
            createDB(bi,"RankedDBTest");


        }
        catch(Exception e){

            e.printStackTrace();
        }



    }
}
