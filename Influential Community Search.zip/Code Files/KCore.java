package org.protiens;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;;

//import org.jgrapht.graph.DefaultEdge;
//import org.jgrapht.graph.SimpleGraph;

public class KCore {

	//SimpleGraph<Integer, DefaultEdge> queryGraph = new SimpleGraph<Integer, DefaultEdge>(DefaultEdge.class);
	
	Map<Integer,List<Integer>> graph = new HashMap<>();
	//Map<Integer,Integer> vDegreeMap = new HashMap<>();
	
	public KCore()
	{
		
	}
	
	public KCore(int V)
	{
		for(int i=0;i<V;i++)
		{
			ArrayList<Integer> nodesList = new ArrayList<>();
			this.graph.put(i, nodesList);
		}
	}
	
	public void addEdge(int u,int v)
	{
		this.graph.get(u).add(v);
		this.graph.get(v).add(u);
	}
	
	/*It returns true if vDegree of v after processing is less
     than k else false
    It also updates vDegree of adjacent if vDegree of v
    is less than k.  And if vDegree of a processed adjacent
    becomes less than k, then it reduces of vDegree of v also,*/
    public boolean  computeKCore(int currNode, Map<Integer,Boolean> visitedMap,Map<Integer,Integer> vDegreeMap, int k){
    	//System.out.println("CurrNode:"+ currNode + "->" + vDegreeMap);
        //Mark the current node as visited
    	visitedMap.put(currNode,true);

        //Recur for all the vertices adjacent to this vertex
        for (int i : this.graph.get(currNode)) {

            //vDegree of v is less than k, then vDegree of
            //adjacent must be reduced
            if( vDegreeMap.get(currNode) < k){
            	vDegreeMap.put(i, vDegreeMap.get(i) - 1);
            	//System.out.println("1. CurrNode:"+ currNode + "->" +"Neighbour:"+i+ "->"+ vDegreeMap);
            }

            //If adjacent is not processed, process it
            if( visitedMap.get(i) == false){

                //If vDegree of adjacent after processing becomes
                //less than k, then reduce vDegree of v also
                if (computeKCore(i, visitedMap, vDegreeMap, k)){
                	vDegreeMap.put(currNode, vDegreeMap.get(currNode) - 1);
                	//System.out.println("2. CurrNode:"+ currNode + "->" +"Neighbour:"+i+ "->"+ vDegreeMap);
                }
            }
        }
        //System.out.println(vDegreeMap);
        //Return true if vDegree of v is less than k
        return vDegreeMap.get(currNode) < k;
    }

    //Prints k cores of an undirected graph
    public List<Integer> printKCores(int k){

        //INITIALIZATION
        //Mark all the vertices as not visited
        //boolean [] visitedMap = new boolean [this.graph.size()];

        /*//Store vDegrees of all vertices
        int [] vDegree = new int [this.graph.size()];
        for(int i = 0;i<this.graph.size();i++) {
            vDegree[i] = this.graph.get(i).size();
        }*/
        Map<Integer,Integer> vDegreeMap = new HashMap<>();
        Map<Integer,Boolean> visitedMap = new HashMap<>();
        
        for(Entry<Integer, List<Integer>> entry : this.graph.entrySet())
        {
        	vDegreeMap.put(entry.getKey(), entry.getValue().size());
        	visitedMap.put(entry.getKey(), false);
        }

        //choose any vertex as starting vertex
        //DFSUtil(0, visitedMap, vDegreeMap, k);

        //DFS traversal to update vDegrees of all
        //vertices,in case they are unconnected
        for(int i:this.graph.keySet())
            if( visitedMap.get(i) == false)
                computeKCore(i, visitedMap, vDegreeMap, k);

        //,
        List<Integer> nodesToDelete = new ArrayList<>();
        
        //System.out.println("K-cores: ");
        for( int v:this.graph.keySet()) {

            //Only considering those vertices which have
            //vDegree >= K after DFS
            if( vDegreeMap.get(v) >= k){
                /*System.out.println(("\n [ ") + v + (" ]"));

                //Traverse adjacency list of v and print only
                //those adjacent which have vvDegree >= k
                //after DFS
                for( int i : this.graph.get(v)) {
                    if ( vDegreeMap.get(i) >= k)
                        System.out.println("-> " + i);
                }*/
            }
            else
            	nodesToDelete.add(v);
        }
        System.out.println(vDegreeMap.toString());
        return nodesToDelete;
    }
    
    
	/*public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int k = 3;
		KCore g1 = new KCore(16);

		//g1.addEdge(0, 4);

		g1.addEdge(1, 2);
		g1.addEdge(1, 3);
		g1.addEdge(1, 8);
		g1.addEdge(1, 13);
		g1.addEdge(1, 15);

		g1.addEdge(2, 8);

		g1.addEdge(3, 4);
		g1.addEdge(3, 5);

		g1.addEdge(4, 5);

		g1.addEdge(6, 7);
		g1.addEdge(6, 9);
		g1.addEdge(6, 10);
		g1.addEdge(6, 11);

		g1.addEdge(7, 10);
		g1.addEdge(7, 11);

		g1.addEdge(8, 9);
		g1.addEdge(8, 11);

		g1.addEdge(9, 10);
		g1.addEdge(9, 11);

		g1.addEdge(12, 13);
		g1.addEdge(12, 14);
		g1.addEdge(12, 15);

		g1.addEdge(13, 14);
		g1.addEdge(13, 15);

		g1.addEdge(14, 15);

		//g1.addEdge(15, 14);

		g1.printKCores(k);
		
		int k = 3; 
		KCore g1 = new KCore(9); 
		g1.addEdge(0, 1); 
		g1.addEdge(0, 2);
		g1.addEdge(1, 2); 
		g1.addEdge(1, 5); 
		g1.addEdge(2, 3); 
		g1.addEdge(2, 4);
		g1.addEdge(2, 5); 
		g1.addEdge(2, 6); 
		g1.addEdge(3, 4); 
		g1.addEdge(3, 6); 
		g1.addEdge(3, 7); 
		g1.addEdge(4, 6); 
		g1.addEdge(4, 7); 
		g1.addEdge(5, 6); 
		g1.addEdge(5, 8); 
		g1.addEdge(6, 7); 
		g1.addEdge(6, 8);
		g1.printKCores(k); 
	}*/

}
