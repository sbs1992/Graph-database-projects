import org.neo4j.graphalgo.PageRankProc;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Result;
import org.neo4j.graphdb.factory.GraphDatabaseFactory;
import org.neo4j.graphdb.factory.GraphDatabaseSettings;
import org.neo4j.kernel.impl.proc.Procedures;
import org.neo4j.kernel.internal.GraphDatabaseAPI;

import java.io.File;
import java.util.*;

public class ICPNew {

    public static HashMap<Integer,Integer> support=new HashMap<>();
    public static HashMap<Integer,Integer> currentcorevalues=new HashMap<>();
    public static HashMap<Integer,Integer> originalcorevalues=new HashMap<>();
    //public static HashMap<Integer,ArrayList<Integer>> neighbours=new HashMap<>();
    public static HashMap<Integer,ArrayList<Integer>> relationshipMap=new HashMap<>();
    public static HashMap<Integer,Double> ranks=new HashMap<>();
    public static TreeMap<Double, Integer> reverseranks=new TreeMap<>();
    public static TreeMap<Double,Integer> decreaseorderranks=new TreeMap<>(Collections.reverseOrder());
    public static HashMap<Integer,ArrayList<ArrayList<Integer>>> table=new HashMap<>();
    public static HashMap<Integer,HashMap<String,ArrayList<ArrayList<Integer>>>> tree=new HashMap<>();

    public static ArrayList<String> vertextracker=new ArrayList<>();
    public static int kmax=0;
    public static GraphDatabaseService data;
    public static int match=0;



    public static void dfsaddition(int j,String ktree,ArrayList<Integer> Su){

        if(vertextracker.contains(ktree))
            return;

        vertextracker.add(ktree);

        ArrayList<Integer> parent=new ArrayList<>();

        String[] mng = ktree.substring(1, ktree.length() - 1).split(",");
        for(String stg:mng){

            parent.add(Integer.parseInt(stg.trim()));
        }



        if(parent.equals(Su)){

            match=1;
            return;
        }

        boolean go=true;
        for(String kt:tree.get(j).keySet()) {

            if (tree.get(j).get(kt).contains(parent)) {

                go=false;
                dfsaddition(j, kt, Su);
                return;
            }
        }


        if(!tree.get(j).get(Su.toString()).contains(parent) && match==0 && go) {
            //match=1;
            tree.get(j).get(Su.toString()).add(parent);
        }





    }

    public static void ConstructTree(){

        for(int i=1 ;i<=kmax;i++) {
            HashMap<String, ArrayList<ArrayList<Integer>>> kcoretree = new HashMap<>();
            for (ArrayList vertex : table.get(i)) {
                ArrayList<ArrayList<Integer>> childnodes = new ArrayList<>();
                Collections.sort(vertex);
                kcoretree.put(vertex.toString(), childnodes);


            }

            tree.put(i,kcoretree);
        }



            for(double w:decreaseorderranks.keySet()){
                int u=decreaseorderranks.get(w);


              /*  Result rs=data.execute(
                        "Match (r:mynode) where r.id="+u+" return r.relations");*/

              //  while(rs.hasNext()) {

                    /*Map<String, Object> nxt = rs.next();
                    String s = nxt.get("r.relations").toString();
                    String[] neigh = s.substring(1, s.length() - 1).split(",");*/
                    //ArrayList<Integer> rel=new ArrayList<>();
                    //int nodesupp=0;
                    for (int sout : relationshipMap.get(u)) {

                        int v = sout;
                        if (ranks.get(v)>ranks.get(u)) {



                            for(int j=1;j<=Math.min(originalcorevalues.get(u),originalcorevalues.get(v));j++){


                                ArrayList<Integer> Su=new ArrayList<>();
                                ArrayList<Integer> Sv=new ArrayList<>();

                                boolean ucheck=false,vcheck=false;
                                for(ArrayList<Integer> rootnodes:table.get(j)){

                                    if(rootnodes.contains(u)){
                                        for(int t:rootnodes){
                                            Su.add(t);
                                        }
                                        ucheck=true;
                                    }
                                    if(rootnodes.contains(v)){
                                        for(int t:rootnodes){
                                            Sv.add(t);
                                        }

                                        vcheck=true;
                                    }

                                    if(ucheck && vcheck){
                                        break;
                                    }

                                }

                                Collections.sort(Su);
                                Collections.sort(Sv);



                                if(!Su.equals(Sv)){


                                    boolean flag=true;

                                    for(String ktree:tree.get(j).keySet()){

                                        if(tree.get(j).get(ktree).contains(Sv)){
                                            flag=false;


                                            dfsaddition(j,ktree,Su);
                                            vertextracker=new ArrayList<>();
                                            match=0;
                                            break;

                                        }
                                    }

                                    if(flag){
                                        if(!tree.get(j).get(Su.toString()).contains(Sv))
                                        tree.get(j).get(Su.toString()).add(Sv);
                                        if(tree.get(j).get(Sv.toString()).contains(Su)){
                                            tree.get(j).get(Sv.toString()).remove(Su);
                                        }
                                    }


                                }

                            }

                        }
                    }
              //  }



            }




    }

    public static void calculateSupport(){
        //Result rs;
        for(int n:currentcorevalues.keySet()){

         /*   rs=data.execute(
                    "Match (r:mynode) where r.id="+n+" return r.relations");*/

         /*
            while(rs.hasNext()){

                Map<String,Object> nxt=rs.next();
                String s=nxt.get("r.relations").toString();
                String[] neigh=s.substring(1,s.length()-1).split(",");
                //ArrayList<Integer> rel=new ArrayList<>();*/
                int nodesupp=0;
                for(Integer sout:relationshipMap.get(n)){

                    if(currentcorevalues.get(sout)>=currentcorevalues.get(n)){
                        nodesupp++;
                    }
                }

               support.put(n,nodesupp);
                //neighbours.put(id,rel);


           // }


        }


    }

    public static void UpdateCore(int u,int k,HashMap<Integer,ArrayList<Integer>> S,ArrayList<Integer> U){

        if(currentcorevalues.get(u)!=-1){

            if(!S.get(currentcorevalues.get(u)+1).contains(u))
            S.get(currentcorevalues.get(u)+1).add(u);
        }

        if(!U.contains(u)){
            U.add(u);
        }

      /*  Result rs=data.execute(
                "Match (r:mynode) where r.id="+u+" return r.relations");*/

      //  while(rs.hasNext()){

            /*Map<String,Object> nxt=rs.next();
            String s=nxt.get("r.relations").toString();
            String[] neigh=s.substring(1,s.length()-1).split(",");*/
            //ArrayList<Integer> rel=new ArrayList<>();
            //int nodesupp=0;
            for(int sout:relationshipMap.get(u)){

                int v=sout;
                if(originalcorevalues.get(v)>=currentcorevalues.get(u)){

                    if(currentcorevalues.get(v)==-1 || U.contains(v)) {
                        continue;
                    }
                    else{

                        if((currentcorevalues.get(u)==-1 && currentcorevalues.get(v)<=k) || (currentcorevalues.get(u)!=-1 && currentcorevalues.get(v)==currentcorevalues.get(u)+1)){

                            support.put(v,support.get(v)-1);

                            if(support.get(v)<currentcorevalues.get(v)){

                                currentcorevalues.put(v,currentcorevalues.get(v)-1);
                                UpdateCore(v,k,S,U);
                            }

                        }

                    }




                }
            }




     //   }



    }

    public static void UpdateSupport(ArrayList<Integer> U){

        for(int u:U){

            support.put(u,0);

            if(currentcorevalues.get(u)==-1){
                continue;
            }
            else{

                /*Result rs=data.execute(
                        "Match (r:mynode) where r.id="+u+" return r.relations");*/

              //  while(rs.hasNext()) {

                   /* Map<String, Object> nxt = rs.next();
                    String s = nxt.get("r.relations").toString();
                    String[] neigh = s.substring(1, s.length() - 1).split(",");*/
                    //ArrayList<Integer> rel=new ArrayList<>();
                    //int nodesupp=0;
                    for (int sout : relationshipMap.get(u)) {

                        int v = sout;
                        if (originalcorevalues.get(v) >= currentcorevalues.get(u)) {

                            if(currentcorevalues.get(v)>=currentcorevalues.get(u)){
                                support.put(u,support.get(u)+1);
                            }
                        }
                    }
               // }

            }

        }

    }




    public static void main(String[] args) throws Exception{

        Result rs;

         data = new GraphDatabaseFactory()

                .newEmbeddedDatabaseBuilder(new File("RankedDBTest"))

                .setConfig(GraphDatabaseSettings.pagecache_memory, "6144M" )

                .setConfig(GraphDatabaseSettings.string_block_size, "60" )

                .setConfig(GraphDatabaseSettings.array_block_size, "300" )

                .newGraphDatabase();


/*

        Procedures procedures = ((GraphDatabaseAPI) data).getDependencyResolver().resolveDependency(Procedures.class);

        procedures.registerProcedure(PageRankProc.class);
*/



        rs=data.execute(
                "Match (r:mynode) return r.id, r.weight,r.corevalue,r.relation_count,r.relations");

        while(rs.hasNext()){

            Map<String,Object> nxt=rs.next();
            String s=nxt.get("r.relations").toString();
            String[] neigh=s.substring(1,s.length()-1).split(",");
            ArrayList<Integer> rel=new ArrayList<>();
            for(String sout:neigh){

                rel.add(Integer.parseInt(sout.trim()));
            }

            int id=Integer.parseInt(nxt.get("r.id")+"");
            //neighbours.put(id,rel);
            relationshipMap.put(id,rel);
            int ccore=Integer.parseInt(nxt.get("r.corevalue")+"");
            if(ccore>kmax){
                kmax=ccore;
            }

            currentcorevalues.put(id,ccore);
            originalcorevalues.put(id,ccore);
            ranks.put(id,Double.parseDouble(nxt.get("r.weight")+""));
            reverseranks.put(Double.parseDouble(nxt.get("r.weight")+""),id);
            decreaseorderranks.put(Double.parseDouble(nxt.get("r.weight")+""),id);
        }

     /*   //done for tree construction part...
        ArrayList<Double> tempnodes=new ArrayList<>();

        for(double dnodes:reverseranks.keySet()){
            tempnodes.add(dnodes);
        }

        for(int i=tempnodes.size()-1;i>=0;i--){

            decreaseorderranks.put(tempnodes.get(i),reverseranks.get(tempnodes.get(i)));

        }

       */


        calculateSupport();


       //initialize table ITi..

        for(int i=1;i<=kmax;i++){
            ArrayList<ArrayList<Integer>> atab = new ArrayList<ArrayList<Integer>>();
            table.put(i,atab);
        }


        int k=0;
        for(double w:reverseranks.keySet()){

            // defining S...
            HashMap<Integer,ArrayList<Integer>> S=new HashMap<>();

            int u=reverseranks.get(w);
            for(int i=1;i<=currentcorevalues.get(u);i++){

                ArrayList<Integer> unodes=new ArrayList<>();
                unodes.add(u);
                S.put(i,unodes);
            }
            k=currentcorevalues.get(u);
            currentcorevalues.put(u,-1);
            ArrayList<Integer> U=new ArrayList<>();
            UpdateCore(u,k,S,U);
            UpdateSupport(U);

            for(int j=1;j<=k;j++){

                table.get(j).add(S.get(j));
            }



        }

        //System.out.println(table);
        System.out.println("table...");
        for(int dis:table.keySet()){

            System.out.println("k="+dis+" - "+table.get(dis));
        }

        System.out.println();



        ConstructTree();


        //System.out.println(tree);

        System.out.println("Tree...");

        for(int dis:tree.keySet()){
            System.out.println("k="+dis+" - "+tree.get(dis));
        }
    }
}
